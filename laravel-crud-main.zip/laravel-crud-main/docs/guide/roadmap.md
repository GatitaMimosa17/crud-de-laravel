# Roadmap

- Add support for Livewire
- Add support for Laravel Jetstream
