# License

The software is licensed using a MIT License. It means you
can do whatever you want with it (including using it for
commercial purposes freely), as long as you include the
original copyright and license notice in any copy of the
software/source.
