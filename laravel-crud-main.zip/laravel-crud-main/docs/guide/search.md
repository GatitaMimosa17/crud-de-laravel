# Inbuilt search

A very simple search is added to the list view by default.
It searches the first text column of the table and filters
the results.

This generated search code is just a placeholder, and you
should customize it as per your own needs.

> ![Inbuilt search](https://cdn.articlevideorobot.com/hosted/22-12-2022/selection-306-99d5.webp)  
> (Inbuilt search)

To modify the search algorithm just edit the `index` method
of the Resource controller for that route.