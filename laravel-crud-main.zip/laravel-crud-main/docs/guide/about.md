# About

**Found any bugs?** Report them on the [issue tracker](https://github.com/san-kumar/laravel-crud/issues).

**Want to contribute?** Fork the project on GitHub and send a
pull request.

**Like the project?** Star it on GitHub.
