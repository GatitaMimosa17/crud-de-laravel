[![Software License](https://img.shields.io/badge/license-MIT-green.svg?style=flat-square)](LICENSE.md)
[![Build Status](https://img.shields.io/circleci/project/github/san-kumar/laravel-crud.svg?style=flat-square)](https://circleci.com/gh/san-kumar/laravel-crud)
[![Coverage Status](https://img.shields.io/badge/coverage-94%25-brightgreen)](https://raw.githack.com/san-kumar/laravel-crud/main/build/coverage/index.html)
[![Latest Version on Packagist](https://img.shields.io/packagist/v/san-kumar/laravel-crud.svg?style=flat-square)](https://packagist.org/packages/san-kumar/laravel-crud)
[![Total Downloads](https://img.shields.io/packagist/dt/san-kumar/laravel-crud.svg?style=flat-square)](https://img.shields.io/packagist/dt/san-kumar/laravel-crud.svg?style=flat-square)

