<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Casts\AsArrayObject;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class _model_ extends Model {
    use HasFactory;

    /*_softdelete_*/

    protected $table = '_tablename_';
    protected $fillable = [/*_fillable_*/];

    /*_casts_*/

    /*_hasmany_*/

    /*_belongsto_*/
}
