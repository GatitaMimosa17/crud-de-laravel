<x-larastrap::radios name="_id_" label="_label_" :options="['1'=>'Yes', '0'=>'No']" :value="_val_" color="primary"/>
