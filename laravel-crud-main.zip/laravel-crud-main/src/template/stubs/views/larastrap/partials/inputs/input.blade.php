<x-larastrap::_laratype_ name="_id_" label="_label_" :value="_val_" _required_ />
