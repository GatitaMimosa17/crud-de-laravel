@foreach($fields as $field)
    {!! $input($field) !!}
@endforeach
