<textarea name="_id_" id="_id_" @class(["form-control", 'is-invalid'=> $errors->has('_id_')]) _required_>{{_val_}}</textarea>
