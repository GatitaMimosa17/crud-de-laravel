{{ Str::limit($_var_->_col_, 50) ?: "(blank)"}}
