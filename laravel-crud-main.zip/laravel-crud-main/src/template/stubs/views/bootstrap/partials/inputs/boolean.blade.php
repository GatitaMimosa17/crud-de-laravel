<div>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="_id_" id="_id__yes" value="1" @checked((_val_) == '1') _required_>
        <label class="form-check-label" for="_id__yes"">Yes</label>
    </div>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="_id_" id="_id__no" value="0" @checked((_val_) == '0') _required_>
        <label class="form-check-label" for="_id__no"">No</label>
    </div>
</div>
