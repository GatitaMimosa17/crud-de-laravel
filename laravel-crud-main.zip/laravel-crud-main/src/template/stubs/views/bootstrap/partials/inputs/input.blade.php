<input type="_type_" name="_id_" id="_id_" value="{{_val_}}" _required_ @class(["form-control", 'is-invalid'=> $errors->has('_id_')])>
