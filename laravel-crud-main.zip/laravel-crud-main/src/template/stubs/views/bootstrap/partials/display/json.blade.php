<textarea class="form-control" readonly>@json($_var_->_col_, JSON_PRETTY_PRINT)</textarea>
