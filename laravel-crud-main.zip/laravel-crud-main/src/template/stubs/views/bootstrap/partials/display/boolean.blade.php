{{ $_var_->_col_ ? "Yes" : "No" }}
