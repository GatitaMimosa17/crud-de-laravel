{{ $_var_->_col_ ?: "(blank)" }}
