<?php

return [
    'template_dir' => NULL,
];